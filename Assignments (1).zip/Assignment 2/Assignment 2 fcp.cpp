#include<stdio.h>
int main(){
	int num = 0;
	printf("Enter the integer: ");
	scanf("%d",&num);
	
	if(num % 2==0){
		printf("Integer is even");
	}
	else{
		printf("Integer is odd");
	}
	return 0;
}

