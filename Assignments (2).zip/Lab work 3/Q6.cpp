//Write a C program to calculate the electricity bill using the following rates: ?5 per unit for the first
//100 units, ?7 per unit for the next 100 units, and ?10 per unit above 200 units. Calculate the bill
//progressively for each slab.

#include<stdio.h>
int main(){
	int unit , bill;
	printf("enter the number of units: ");
	scanf("%d",&unit);
	
	if(unit <= 100){
		bill = unit * 5;
		printf("%d",bill);
	}
	else if (100 < unit <= 200){
		bill = (100 * 5) + ((unit - 100) * 7);
		printf("%d",bill);
	}
	else{
		bill = (100 * 5) + (100 * 7) + ((unit - 200) * 10);
		printf("%d",bill);
    }
    return 0;
}