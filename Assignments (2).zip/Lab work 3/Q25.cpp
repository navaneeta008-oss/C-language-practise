//25. Prime number: Accept an integer and determine whether it is prime using a loop and if-else.

#include<stdio.h>
int main(){
	int n,i;
	int prime = 0;
	printf("Enter the integer: ");
	scanf("%d",&n);
	
	for(i = 1; i <= n ; i++){
		prime = prime + (n % i ==0);
	}
	printf("Is prime number(1 = yes , 0 = no): %d\n",(prime == 2));
	return 0;
}

