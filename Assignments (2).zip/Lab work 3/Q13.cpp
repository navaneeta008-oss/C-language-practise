//Write a C program to print all integers from 1 to 100 using a for loop.

#include<stdio.h>
int main(){
	int i ;
	for(i = 1 ; i <= 100 ; i++){
	printf("\n%d",i);
}
	return 0;
}