//18. Accept an integer and count the number of digits using a for loop. Do not convert the number to a
//string.

#include<stdio.h>
int main(){
	int n , i , count;
	printf("Enter an Integer: ");
	scanf("%d",&n)
	
	for(i = 0 ;i = )
	
}