//12. Admission eligibility:

#include<stdio.h>
int main(){
	int maths , phy , chem;
	printf("Enter the marks obtained in Mathematics (out of 100): ");
	scanf("%d",&maths);
	printf("Enter the marks obtained in Physics (out of 100): ");
	scanf("%d",&phy);
	printf("Enter the marks obtained in Chemistry (out of 100): ");
	scanf("%d",&chem);
	
	if(maths >= 60){
		if(chem >= 50 && phy >= 50){
			printf("You are eligible for admission");
		}
		else{
			printf("You are not eligible for admission");
		}
}
	else{
			printf("You are not eligible , please try next year");
		}
	
	return 0;
	
}