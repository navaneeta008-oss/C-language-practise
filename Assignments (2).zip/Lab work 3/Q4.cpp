//4. Write a C program to check whether a person is eligible to vote. Consider 18 years as the minimum
//age.

#include<stdio.h>
int main(){
	int age;
	printf("Enter your age: ");
	scanf("%d",&age);
	
	if(age>=18){
		printf("You are eligible to vote");
	}
	else{
		printf("you are not eligible to vote");
	}
	return 0;
}