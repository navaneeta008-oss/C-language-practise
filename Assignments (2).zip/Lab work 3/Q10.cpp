//10. Triangle classification:

#include<stdio.h>
int main(){
	
}