//11. Login verification:
//
//#include<stdio.h>
//int main(){
//	char name ,Name;
//	int pin ,PIN;
//	// predined values
//	Name = 'Harry';
//	PIN = 123;
//		
//	printf("enter username(only 6 digit char): ");
//	scanf("%s",&name);
//	printf("\nenter PIN(3 digits only) : ");
//	scanf("%d",&pin);
//	
//	if(name == Name && pin == PIN){
//	printf("Login Successful");
//	}
//	else if(name == Name && pin != PIN){
//		printf("Incorrect PIN\n try again");
//	}
//	else if(name!=Name && pin == PIN){
//		printf("Incorrect username\n try again");
//    }
//    else{
//    	printf("Try again");
//	}
//	
//	return 0;
//	
//}