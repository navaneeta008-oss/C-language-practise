//Grade calculation: Accept a student's marks out of 100 and display the grade using the following
//criteria:

#include<stdio.h>
int main(){
	int marks;
	printf("Enter your marks out of 100: ");
	scanf("%d",&marks);
	
	if(marks<40){
		printf("You failed");
	}
	else if(40<= marks && marks<= 59){
		printf("You got a D");
	}
	else if(60<= marks && marks <= 74){
		printf("You got a C");
	}
	else if(75<= marks && marks <=89){
		printf("You got a B");
	}
	else{
		printf("You got a A");
	}
	return 0;
}