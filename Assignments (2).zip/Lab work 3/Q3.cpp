//Write a C program to find the greater of two numbers.

#include<stdio.h>
int main(){
	int a , b;
	printf("Enter number 1: ");
	scanf("%d",&a);
	
	printf("Enter number 2: ");
	scanf("%d",&b);
	
	if (a > b) {
        printf("%d is greater than %d.\n", a, b);
    } else if (a > b) {
        printf("%d is greater than %d.\n", a, b);
    } else {
        printf("Both numbers are equal.\n");
    }

    return 0;
}