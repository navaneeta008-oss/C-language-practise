//Accept an integer and print its multiplication table up to 10.

#include<stdio.h>
int main(){
	int num,i ;
	printf("Enter an Integer: ");
	scanf("%d",&num);
	
	for(i= 1; i <= 10 ;i++){
		printf("%d x %d = %d\n",num,i,num*i);
	}
	return 0;
}