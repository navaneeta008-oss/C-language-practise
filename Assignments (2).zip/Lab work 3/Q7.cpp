//7. Greatest of three numbers: Write a C program to accept three integers and find the greatest number
//using nested if-else.

#include<stdio.h>
int main(){
	int a ,b,c ;
	printf("Enter three integers: ");
	scanf("%d %d %d",&a ,&b, &c);
	
	if(a> b || a > c){
		if(a<c){
		printf("Greatest number is %d",c);
	}
		else if(a<b){
			printf("Greatest number is %d",b);
		}
		else{
			printf("Greatest number is %d",a);
		}
	}
		
	}
	else if(b>a || b>c){
		if(a>b){
			printf("Greatest number is %d",a);
		}
		else if(c>b){
			printf("Greatest number is %d",c);
		}
		else{
		printf("Greatest number is %d",b);}
	}
	else if(c>a || c>b){
		if(a>c){
			printf("Greatest number is %d",a);
		}
		else if(b>c){
			printf("Greatest number is %d",b);
		}
		else{
		printf("Greatest number is %d",c);}
	}
}