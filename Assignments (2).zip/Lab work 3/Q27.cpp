//27. Fibonacci series: Accept the number of terms n and print the first n terms of the Fibonacci series
//using a loop.

#include<stdio.h>
int main(){
	int n,i;
	int a = 0;
	int b = 1;
	int next ;
	
	printf("Enter the integer: ");
	scanf("%d",&n);
	printf(" Fibonacci series:");
	
	for(i = 0; i <= n; i++){
		printf("%d\n",a);
		next = a + b;
		a =b;
		b = next;
	}
	printf("\n");
	return 0;
}