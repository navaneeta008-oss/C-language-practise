//Accept an integer n and calculate the sum of the first n natural numbers.

#include<stdio.h>
int main(){
	int n, i;
	int a = 0;
	int b = 1;
	int c;
	printf("Enter an Integer: ");
	scanf("%d",&n);
	
	for(i = 0 ; i < n ; i++){
		printf("%d\n",a);
		c = a + b;
		a = b;
		b = c;
	}
	printf("\n");
	return 0;
}