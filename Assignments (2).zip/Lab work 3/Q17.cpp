//17. Accept an integer and calculate its factorial using a for loop. Handle negative input appropriately.

#include<stdio.h>
int main(){
	int n ,i;
	int f =1;
	printf("Enter an Integer: ");
	scanf("%d",&n);
	
	if(n > 0){
		for(i = 1 ; i <= n ; i++){
			f = f*i;
		}
		printf("factorial of %d =  %d", n , f);
	}
	else{
		printf("\please insert non negative number");
	}
	return 0;
}