//Menu-driven calculator: Display a menu for addition, subtraction, multiplication, and division.
//Accept the user's choice and two numbers, then display the result using if-else. Handle division by
//zero.

#include <stdio.h>

int main() {
    int choice;
    int n;
    int a, b;
    
    printf("\tMENU DRIVEN CALCULATOR\t\n");
    printf("Choose between 1 (addition), 2 (subtraction), 3 (multiplication), 4 (division):\n");
    
    printf("Enter the choice: ");
    scanf("%d", &choice); 
    
    printf("Insert number 1: ");
    scanf("%d", &a);
    printf("Insert number 2: ");
    scanf("%d", &b);
    
    switch(choice) { 
        case 1:
            n = a + b;
            printf("Result: %d\n", n);
            break;
        case 2:
            n = a - b;
            printf("Result: %d\n", n);
            break;
        case 3:
            n = a * b;
            printf("Result: %d\n", n);
            break;
        case 4:
            if (b == 0) {
                printf("Error: Division by zero is not allowed.\n");
            } else {
                n = a / b;
                printf("Result: %d\n", n);
            }
            break;
        default:
            printf("Invalid choice!\n");
    }
    
    return 0;
}