//29. Number guessing: Store a predefined secret number. Allow the user to enter guesses until the
//correct number is entered, displaying “Too high” or “Too low” after each incorrect guess.

#include<stdio.h>
int main(){
	int secret_number = 1008;
	int num = 0;
	
	printf("\tNumber guessing\t");
	printf("\nEnter your guessing: ");
	scanf("%d",&num);
	
	if(num > 1008){
		printf("Too High");
	}
	else if(num < 1008){
		printf("Too Low");
	}
	else if(num == 1008){
		printf("You guessed it write!");
	}
	else{
		printf("Please guess again");
	}
	return 0;
}