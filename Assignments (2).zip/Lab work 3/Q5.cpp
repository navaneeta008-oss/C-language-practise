//Write a C program to determine whether a student has passed or failed. Assume the passing marks
//are 40 out of 100.

#include<stdio.h>
int main(){
	int marks;
	printf("Enter the total marks obtained out of 100: ");
	scanf("%d",&marks);
	
	if(marks < 40){
		printf("you are failed");
	}
	else{
		printf("you are passed");
	}
}