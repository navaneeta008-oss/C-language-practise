//Write a C program to print all even numbers between 1 and 50.

#include<stdio.h>
int main(){
	int i,n;
	for(i = 2; i<50 ; i++){
		if(i%2==0){
		
		printf("%d\n",i);
	}
}
	return 0;
}