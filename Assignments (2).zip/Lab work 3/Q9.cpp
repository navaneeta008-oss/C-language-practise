//9. Leap year: Write a C program to determine whether a given year is a leap year using nested
//if-else. A leap year is divisible by 400, or divisible by 4 but not by 100.

#include<stdio.h>
int main(){
	int year;
	printf("Enter the year: ");
	scanf("%d",&year);
	
	if(year%400==0){
		printf("%d is a leap year",year);
	}
	else if (year % 4 == 0 && year != 100){
		printf("%d is a leap year",year);
	}
	else{
		printf("%d is not a leap year",year);
	}
	return 0;
}