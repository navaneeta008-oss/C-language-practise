//Electricity usage analysis: Accept the electricity consumption of five households using a loop. For
//each household, classify consumption as Low (below 100 units), Moderate (100–300 units), or High
//(above 300 units). Finally, display the number of households in each category.

#include<stdio.h>
int main(){
	int i,n ;
	
	for(i = 1; i<= 5; i++){
		printf(" \nElectricity consumption of households: ");
		scanf("%d",&n);
		if(n>300){
			printf("High");
		}
		else if(100<n && n < 300){
			printf("Moderate");
		}
		else{
			printf("Low");
		}
		
	}
	return 0;
}